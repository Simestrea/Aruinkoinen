#pragma once
#include "ui_root.hpp"
#include "raylib.h"
#include "init.hpp"
#include "text.hpp"
#include <string>
#include <cstddef>

namespace aur {

// ==========================================
// TextBox���ɱ༭�ĵ����ı������
//
// �ص㣺
//   - �����ý��㣬��������ʵʱ�༭
//   - ֧�� UTF-8�����������Զ������ֽڴ�����
//   - ʧ��ʱ��ʾ placeholder
//   - ȫ��ͬʱֻ��һ�� TextBox ��ý���
//   - �˸�֧�ֳ����ظ�ɾ��
//
// �÷����ڽ�ɫ�ű����
//   aur::TextBox input("����������֡�", 200, 300, 400, 44, 20);
//   while (true) {
//       input.Draw();
//       if (input.Submitted()) {
//           auto name = input.ConsumeText();
//           c.Say("��ã�" + name + "!", 2.0f);
//       }
//       co_await aur::WaitNextFrame{};
//   }
//
// ˵����
//   - Draw() �ڲ�ͬʱ��������ͻ��ƣ����Ա�����
//     virtualScreen.Begin() / End() ֮�����
//   - ��Ҫ������ʾ/����ʱ�� SetFont("fonts/xxx.ttc")
// ==========================================
class TextBox : public Widget {
private:
    // ---------- ���� ----------
    std::string text_{};
    std::string placeholder_{};
    int maxChars_{64};   // UTF-8 ������ޣ����İ� 1 ���㣩

    // ---------- ���� ----------
    float x_{0.0f};
    float y_{0.0f};
    float width_{200.0f};
    float height_{40.0f};
    float padding_{8.0f};
    int fontSize_{20};

    // ---------- ��ʽ ----------
    std::string fontName_{};   // �� = Ĭ������
    Color textColor_{BLACK};
    Color bgColor_{RAYWHITE};
    Color borderColor_{LIGHTGRAY};
    Color focusBorderColor_{DARKGRAY};
    Color placeholderColor_{GRAY};

    // ---------- ״̬ ----------
    bool isHidden_{false};
    bool submitted_{false};
    float cursorTimer_{0.0f};
    bool cursorVisible_{true};
    float backspaceHold_{0.0f};
    float backspaceRepeat_{0.0f};

    // ---------- ���㣨ȫ��Ψһ�� ----------
    static TextBox*& FocusedSlot() {
        static TextBox* p = nullptr;
        return p;
    }

    // ---------- UTF-8 ���� ----------
    static int CodepointCount(const std::string& s) {
        int n = 0;
        for (unsigned char c : s) {
            if ((c & 0xC0) != 0x80) ++n;   // ֻ��ǰ���ֽ�
        }
        return n;
    }

    static void AppendCodepoint(std::string& s, int cp) {
        if (cp < 0x80) {
            s += static_cast<char>(cp);
        } else if (cp < 0x800) {
            s += static_cast<char>(0xC0 | (cp >> 6));
            s += static_cast<char>(0x80 | (cp & 0x3F));
        } else if (cp < 0x10000) {
            s += static_cast<char>(0xE0 | (cp >> 12));
            s += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
            s += static_cast<char>(0x80 | (cp & 0x3F));
        } else {
            s += static_cast<char>(0xF0 | (cp >> 18));
            s += static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
            s += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
            s += static_cast<char>(0x80 | (cp & 0x3F));
        }
    }

    static void PopLastChar(std::string& s) {
        if (s.empty()) return;
        size_t i = s.size();
        while (i > 0) {
            --i;
            if ((s[i] & 0xC0) != 0x80) { s.erase(i); return; }
        }
        s.clear();
    }

    Font ResolveFont() const {
        if (fontName_.empty()) return GetFontDefault();
        return detail::fontPool.GetOrLoad(fontName_);
    }

    bool TouchingMouse() const {
        const Vector2 m = detail::virtualScreen.GetVirtualMousePosition();
        return m.x >= x_ && m.x <= x_ + width_ &&
               m.y >= y_ && m.y <= y_ + height_;
    }

    void HandleKeyboard(float dt) {
        // ��������
        int cp;
        while ((cp = GetCharPressed()) > 0) {
            if (CodepointCount(text_) < maxChars_) {
                AppendCodepoint(text_, cp);
            }
        }

        // �˸񣨰���˲�� + �����ظ���
        bool doBackspace = false;
        if (IsKeyPressed(KEY_BACKSPACE)) {
            doBackspace = true;
            backspaceHold_ = 0.0f;
            backspaceRepeat_ = 0.0f;
        } else if (IsKeyDown(KEY_BACKSPACE)) {
            backspaceHold_ += dt;
            if (backspaceHold_ > 0.4f) {
                backspaceRepeat_ += dt;
                if (backspaceRepeat_ > 0.05f) {
                    backspaceRepeat_ = 0.0f;
                    doBackspace = true;
                }
            }
        } else {
            backspaceHold_ = 0.0f;
            backspaceRepeat_ = 0.0f;
        }
        if (doBackspace) PopLastChar(text_);

        // �ύ / ȡ��
        if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_KP_ENTER)) {
            submitted_ = true;
        }
        if (IsKeyPressed(KEY_ESCAPE)) {
            FocusedSlot() = nullptr;
        }
    }

public:
    TextBox(const std::string& placeholder,
            float x, float y, float width, float height,
            int fontSize = 20)
        : placeholder_{placeholder},
          x_{x}, y_{y}, width_{width}, height_{height},
          fontSize_{fontSize}
    {}

    ~TextBox() {
        if (FocusedSlot() == this) FocusedSlot() = nullptr;
    }

    TextBox(const TextBox&) = delete;
    TextBox& operator=(const TextBox&) = delete;
    TextBox(TextBox&&) = delete;
    TextBox& operator=(TextBox&&) = delete;

    // ---------- ���� ----------
    void SetText(const std::string& s) { text_ = s; }
    const std::string& GetText() const noexcept { return text_; }
    void Clear() { text_.clear(); submitted_ = false; }
    bool IsEmpty() const noexcept { return text_.empty(); }
    int Length() const { return CodepointCount(text_); }

    // ---------- ���� ----------
    void SetPosition(float x, float y) { x_ = x; y_ = y; }
    void SetSize(float w, float h) { width_ = w; height_ = h; }
    void SetFontSize(int s) { fontSize_ = s; }
    void SetMaxChars(int n) { maxChars_ = n; }

    // ---------- ��ʽ ----------
    void SetFont(const std::string& path) { fontName_ = path; }
    void SetPlaceholder(const std::string& p) { placeholder_ = p; }
    void SetTextColor(Color c) { textColor_ = c; }
    void SetBackgroundColor(Color c) { bgColor_ = c; }
    void SetBorderColor(Color c) { borderColor_ = c; }
    void SetFocusBorderColor(Color c) { focusBorderColor_ = c; }
    void SetPlaceholderColor(Color c) { placeholderColor_ = c; }

    // ---------- ���� ----------
    void Focus() { FocusedSlot() = this; }
    void Blur()  { if (FocusedSlot() == this) FocusedSlot() = nullptr; }
    bool IsFocused() const noexcept { return FocusedSlot() == this; }

    // ---------- ��ʾ ----------
    void Show() { isHidden_ = false; }
    void Hide() { isHidden_ = true; }
    bool IsHidden() const noexcept { return isHidden_; }

    // ---------- �ύ ----------
    // �� Enter �� Submitted() Ϊ true��ֱ�� ClearSubmitted / ConsumeText ���
    bool Submitted() const noexcept { return submitted_; }
    void ClearSubmitted() { submitted_ = false; }

    // ȡ�����ݲ���գ��ʺ�"�ύ��Ͱѿ����"�ĳ�����
    std::string ConsumeText() {
        std::string r = text_;
        text_.clear();
        submitted_ = false;
        return r;
    }

    // ---------- Widget �ӿ� ----------
    Rectangle GetBounds() const override {
        return { x_, y_, width_, height_ };
    }

    bool IsFocusable() const override { return true; }

    void OnFocusGained() override { FocusedSlot() = this; }

    void OnFocusLost() override {
        if (FocusedSlot() == this) FocusedSlot() = nullptr;
    }

    // ---------- ���� + ���� ----------
    void Draw() override {
        if (isHidden_) return;

        const float dt = GetFrameTime();

        // 1) ֻ�н����Ŵ�������
        if (FocusedSlot() == this) {
            HandleKeyboard(dt);
        }

        // 2) �����˸
        if (FocusedSlot() == this) {
            cursorTimer_ += dt;
            if (cursorTimer_ >= 0.5f) {
                cursorTimer_ -= 0.5f;
                cursorVisible_ = !cursorVisible_;
            }
        } else {
            cursorTimer_ = 0.0f;
            cursorVisible_ = true;
        }

        // 3) ����
        const bool focused = (FocusedSlot() == this);
        const Rectangle bounds{ x_, y_, width_, height_ };

        DrawRectangleRec(bounds, bgColor_);
        DrawRectangleLinesEx(bounds, 2.0f,
                             focused ? focusBorderColor_ : borderColor_);

        Font font = ResolveFont();
        const bool empty = text_.empty();
        const char* display = empty ? placeholder_.c_str() : text_.c_str();
        const Color color  = empty ? placeholderColor_ : textColor_;

        const float textY = y_ + (height_ - static_cast<float>(fontSize_)) / 2.0f;
        DrawTextEx(font, display,
                   { x_ + padding_, textY },
                   static_cast<float>(fontSize_), 1.0f, color);

        // ���
        if (focused && cursorVisible_) {
            float cursorX = x_ + padding_;
            if (!empty) {
                Vector2 sz = MeasureTextEx(font, text_.c_str(),
                                           static_cast<float>(fontSize_), 1.0f);
                cursorX += sz.x;
            }
            const float top = textY;
            const float bot = textY + static_cast<float>(fontSize_);
            DrawLine(static_cast<int>(cursorX),
                     static_cast<int>(top),
                     static_cast<int>(cursorX),
                     static_cast<int>(bot),
                     textColor_);
        }
    }
};

} // namespace aur